module.exports = {
  testEnvironment: 'jsdom',
  testTimeout: 30000
};