describe('Login Flow', () => {
  it('should login successfully', () => {
    cy.visit('http://localhost:3000/');
    cy.contains('MERN Testing App');
  });
});