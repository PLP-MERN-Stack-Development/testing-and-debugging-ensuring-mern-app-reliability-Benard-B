import { render, screen, fireEvent } from '@testing-library/react';
import Counter from '../../components/Counter';

test('increments counter', () => {
  render(<Counter />);
  const count = screen.getByTestId('count');
  const button = screen.getByText(/increment/i);

  expect(count.textContent).toBe('0');
  fireEvent.click(button);
  expect(count.textContent).toBe('1');
});