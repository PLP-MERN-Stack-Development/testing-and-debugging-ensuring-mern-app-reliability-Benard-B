exports.add = (a, b) => a + b;

exports.getUser = (req, res) => {
  res.json({ name: 'John Doe', email: 'john@test.com' });
};