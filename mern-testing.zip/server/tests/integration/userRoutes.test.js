const request = require('supertest');
const app = require('../../src/app');

describe('GET /api/user', () => {
  it('returns user data', async () => {
    const res = await request(app).get('/api/user');
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('name', 'John Doe');
  });
});